#!/system/bin/sh
# AX HyperBoost - Post FS Data
# This script runs on BOOT_COMPLETED first sync

MODDIR=${0%/*}

# Early initialization
echo "[$(date)] AX HyperBoost post-fs-data started" >> "$MODDIR/logs/boot.log"

# Set permissions
chmod -R 755 "$MODDIR/system/bin" 2>/dev/null
chmod -R 755 "$MODDIR/webroot" 2>/dev/null
chmod -R 777 "$MODDIR/logs" 2>/dev/null

echo "[$(date)] Permissions set" >> "$MODDIR/logs/boot.log"
