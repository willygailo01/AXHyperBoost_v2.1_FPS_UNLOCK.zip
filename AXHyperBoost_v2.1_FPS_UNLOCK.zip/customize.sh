#!/system/bin/sh
# AX HyperBoost ULTIMATE Installation

ui_print "======================================="
ui_print "  AX HyperBoost ULTIMATE v2.0 EXTREME"
ui_print "  Maximum Performance Engine         "
ui_print "======================================="
ui_print " "
ui_print "Module ID: ax.hyperboost"
ui_print "Version: 2.0 EXTREME"
ui_print "Author: Willy Gailo"
ui_print "AxManager Plugin: Yes"
ui_print " "
ui_print "🔥 FEATURES:"
ui_print "  ✓ Thermal Throttle Control"
ui_print "  ✓ CPU/GPU Max Frequency"
ui_print "  ✓ Touch 240Hz Polling"
ui_print "  ✓ Network Speed Optimization"
ui_print "  ✓ Game Compilation (speed -f)"
ui_print "  ✓ Manual Performance Controls"
ui_print "  ✓ ALL Android Devices Supported"
ui_print " "

if [ "$AXERON" = "true" ]; then
    ui_print "✓ AxManager detected"
    ui_print "✓ Plugin mode enabled"
else
    ui_print "! Running in root mode"
fi

ui_print " "
ui_print "Installing files..."

# Set permissions
set_perm_recursive $MODPATH 0 0 0755 0644
set_perm_recursive $MODPATH/system/bin 0 0 0755 0755
chmod 755 $MODPATH/*.sh 2>/dev/null

# Create logs directory
mkdir -p $MODPATH/logs
chmod 777 $MODPATH/logs

ui_print " "
ui_print "✓ Installation complete!"
ui_print "✓ Reboot to activate"
ui_print " "
ui_print "📱 PROFILES:"
ui_print "  🔋 Battery Saver"
ui_print "  ⚖️  Balanced"
ui_print "  🎮 Gaming Mode"
ui_print "  🚀 EXTREME (⚠️ Max Power)"
ui_print " "
ui_print "🎛️  Access web panel for manual controls!"
ui_print "⚠️  Monitor temperature in EXTREME mode!"
ui_print " "
