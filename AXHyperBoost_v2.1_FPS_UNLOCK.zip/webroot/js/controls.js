// AX HyperBoost ULTIMATE - Manual Controls

// Execute shell command
function exec(cmd) {
    console.log('Executing:', cmd);
    
    // In real implementation, this would call AxManager API
    if (typeof AndroidInterface !== 'undefined') {
        AndroidInterface.executeCommand(cmd);
    } else {
        // Browser fallback - show notification
        showNotification(`Would execute: ${cmd}`, 'info');
    }
}

// CPU Controls
function toggleCPU(enabled) {
    if (enabled) {
        exec('axengine --extreme');
        showNotification('CPU Boost: MAXIMUM', 'success');
    } else {
        exec('axengine --balanced');
        showNotification('CPU Boost: Normal', 'info');
    }
}

function toggleCPUGov(enabled) {
    const gov = enabled ? 'performance' : 'schedutil';
    exec(`for cpu in /sys/devices/system/cpu/cpu*/cpufreq/scaling_governor; do echo "${gov}" > $cpu; done`);
    showNotification(`CPU Governor: ${gov}`, 'success');
}

function toggleCores(enabled) {
    if (enabled) {
        exec('for cpu in /sys/devices/system/cpu/cpu*/online; do echo "1" > $cpu; done');
        showNotification('All CPU cores: ONLINE', 'success');
    } else {
        showNotification('Cores managed by system', 'info');
    }
}

// GPU Controls
function toggleGPU(enabled) {
    if (enabled) {
        exec('gpuopt');
        exec('echo "0" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel');
        exec('echo "0" > /sys/class/kgsl/kgsl-3d0/min_pwrlevel');
        showNotification('GPU: MAXIMUM FREQUENCY', 'success');
    } else {
        exec('echo "6" > /sys/class/kgsl/kgsl-3d0/max_pwrlevel');
        showNotification('GPU: Normal', 'info');
    }
}

function toggleGPUClock(enabled) {
    if (enabled) {
        exec('echo "1" > /sys/class/kgsl/kgsl-3d0/force_clk_on');
        exec('echo "1" > /sys/class/kgsl/kgsl-3d0/force_rail_on');
        exec('echo "1" > /sys/class/kgsl/kgsl-3d0/force_bus_on');
        showNotification('GPU Clock: FORCED ON', 'success');
    } else {
        exec('echo "0" > /sys/class/kgsl/kgsl-3d0/force_clk_on');
        showNotification('GPU Clock: Auto', 'info');
    }
}

function toggleGPUPerf(enabled) {
    const gov = enabled ? 'performance' : 'msm-adreno-tz';
    exec(`echo "${gov}" > /sys/class/kgsl/kgsl-3d0/devfreq/governor`);
    showNotification(`GPU Governor: ${gov}`, 'success');
}

// Thermal Controls
function toggleThermal(enabled) {
    if (enabled) {
        exec('echo "N" > /sys/module/msm_thermal/parameters/enabled');
        exec('stop thermal-engine');
        exec('stop thermald');
        showNotification('⚠️ THERMAL THROTTLE DISABLED!', 'warning');
        
        // Show warning dialog
        setTimeout(() => {
            if (confirm('⚠️ WARNING: Thermal throttling disabled!\n\nThis may cause overheating. Monitor temperature closely.\n\nContinue?')) {
                showNotification('Thermal protection disabled. Use at your own risk!', 'warning');
            } else {
                document.getElementById('thermal').checked = false;
                exec('echo "Y" > /sys/module/msm_thermal/parameters/enabled');
            }
        }, 500);
    } else {
        exec('echo "Y" > /sys/module/msm_thermal/parameters/enabled');
        exec('start thermal-engine');
        exec('start thermald');
        showNotification('Thermal throttle: ENABLED (Safe)', 'success');
    }
}

// Touch Controls
function toggleTouch(enabled) {
    if (enabled) {
        exec('touchboost');
        exec('echo "1" > /sys/module/cpu_boost/parameters/input_boost_enabled');
        exec('echo "200" > /sys/module/cpu_boost/parameters/input_boost_ms');
        showNotification('Touch Response: MAXIMUM', 'success');
    } else {
        exec('echo "0" > /sys/module/cpu_boost/parameters/input_boost_enabled');
        showNotification('Touch Response: Normal', 'info');
    }
}

function toggleTouchPoll(enabled) {
    if (enabled) {
        exec('for rate in /sys/class/input/input*/polling_rate; do echo "4" > $rate; done');
        showNotification('Touch Polling: 240Hz', 'success');
    } else {
        exec('for rate in /sys/class/input/input*/polling_rate; do echo "16" > $rate; done');
        showNotification('Touch Polling: 60Hz', 'info');
    }
}

// Network Controls
function toggleWiFi(enabled) {
    if (enabled) {
        exec('for wifi in /sys/module/wlan/parameters/power_save /sys/module/bcmdhd/parameters/power_save; do echo "0" > $wifi; done');
        showNotification('WiFi Power Save: OFF (Max Speed)', 'success');
    } else {
        exec('for wifi in /sys/module/wlan/parameters/power_save; do echo "1" > $wifi; done');
        showNotification('WiFi Power Save: ON', 'info');
    }
}

function toggleTCP(enabled) {
    if (enabled) {
        exec('echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control');
        exec('echo "1" > /proc/sys/net/ipv4/tcp_window_scaling');
        exec('echo "3" > /proc/sys/net/ipv4/tcp_fastopen');
        exec('echo "8388608" > /proc/sys/net/core/rmem_max');
        exec('echo "8388608" > /proc/sys/net/core/wmem_max');
        showNotification('TCP: Optimized for Speed', 'success');
    } else {
        showNotification('TCP: Default', 'info');
    }
}

// Game Controls
function toggleGames(enabled) {
    if (enabled) {
        exec('axengine --gaming');
        showNotification('Game Optimization: ACTIVE', 'success');
    } else {
        showNotification('Game Optimization: OFF', 'info');
    }
}

function toggleDriver(enabled) {
    if (enabled) {
        exec('settings put global game_driver_prefer_system_driver 0');
        exec('settings put global game_driver_all_apps 1');
        showNotification('Game Driver: FORCED', 'success');
    } else {
        exec('settings put global game_driver_prefer_system_driver 1');
        showNotification('Game Driver: Auto', 'info');
    }
}

function compileGames() {
    showNotification('Compiling all games with speed -f...', 'info');
    
    // Read gamelist and compile
    exec('while IFS= read -r pkg; do [ -z "$pkg" ] || [ "${pkg:0:1}" = "#" ] && continue; cmd package compile -m speed -f "$pkg"; done < /data/user_de/0/com.android.shell/axeron/plugins/ax.hyperboost/config/gamelist.txt');
    
    setTimeout(() => {
        showNotification('✓ All games compiled! Restart games for effect.', 'success');
    }, 2000);
}

// Memory & I/O
function toggleMemory(enabled) {
    if (enabled) {
        exec('echo "5" > /proc/sys/vm/swappiness');
        exec('echo "40" > /proc/sys/vm/vfs_cache_pressure');
        showNotification('Memory: Optimized (Low Swappiness)', 'success');
    } else {
        exec('echo "60" > /proc/sys/vm/swappiness');
        showNotification('Memory: Default', 'info');
    }
}

function toggleIO(enabled) {
    if (enabled) {
        exec('for sched in /sys/block/*/queue/scheduler; do echo "deadline" > $sched; done');
        exec('for ra in /sys/block/*/queue/read_ahead_kb; do echo "4096" > $ra; done');
        exec('for nr in /sys/block/*/queue/nr_requests; do echo "512" > $nr; done');
        showNotification('I/O: MAXIMUM Performance', 'success');
    } else {
        exec('for ra in /sys/block/*/queue/read_ahead_kb; do echo "128" > $ra; done');
        showNotification('I/O: Default', 'info');
    }
}

// Quick Actions
function applyExtreme() {
    if (!confirm('⚠️ APPLY EXTREME MODE?\n\nThis will:\n- Disable thermal throttle\n- Max CPU/GPU frequencies\n- Maximum power consumption\n- May overheat!\n\nContinue?')) {
        return;
    }
    
    showNotification('🚀 APPLYING EXTREME MODE...', 'warning');
    
    // Enable all switches
    document.getElementById('cpuBoost').checked = true;
    document.getElementById('cpuGov').checked = true;
    document.getElementById('cpuCores').checked = true;
    document.getElementById('gpuBoost').checked = true;
    document.getElementById('gpuClock').checked = true;
    document.getElementById('gpuPerf').checked = true;
    document.getElementById('thermal').checked = true;
    document.getElementById('touch').checked = true;
    document.getElementById('touchPoll').checked = true;
    document.getElementById('wifi').checked = true;
    document.getElementById('tcp').checked = true;
    document.getElementById('games').checked = true;
    document.getElementById('driver').checked = true;
    document.getElementById('memory').checked = true;
    document.getElementById('io').checked = true;
    
    // Execute all
    exec('axengine --extreme');
    
    setTimeout(() => {
        showNotification('🔥 EXTREME MODE ACTIVE! Monitor temperature!', 'success');
    }, 1000);
}

function resetAll() {
    if (!confirm('Reset all settings to Balanced mode?')) {
        return;
    }
    
    showNotification('Resetting to Balanced...', 'info');
    
    // Disable extreme switches
    document.getElementById('thermal').checked = false;
    
    // Execute balanced mode
    exec('axengine --balanced');
    
    // Reload page to reset switches
    setTimeout(() => {
        location.reload();
    }, 1000);
}

// Load device info
function loadDeviceInfo() {
    // In real implementation, get from system
    const device = 'Android Device';
    document.getElementById('deviceInfo').textContent = device;
}

// Initialize on load
document.addEventListener('DOMContentLoaded', function() {
    loadDeviceInfo();
    
    // Set default states (all ON for extreme mode)
    setTimeout(() => {
        document.getElementById('cpuBoost').checked = true;
        document.getElementById('cpuGov').checked = true;
        document.getElementById('gpuBoost').checked = true;
        document.getElementById('gpuPerf').checked = true;
        document.getElementById('touch').checked = true;
        document.getElementById('wifi').checked = true;
        document.getElementById('tcp').checked = true;
        document.getElementById('memory').checked = true;
        document.getElementById('io').checked = true;
    }, 500);
});
