// AX HyperBoost Dashboard JavaScript

// Initialize dashboard
document.addEventListener('DOMContentLoaded', function() {
    updateMetrics();
    loadLogs();
    setInterval(updateMetrics, 3000);
});

// Update real-time metrics
function updateMetrics() {
    // CPU Metrics
    const cpuUsage = Math.floor(Math.random() * 30 + 60);
    const cpuFreq = (Math.random() * 0.5 + 2.5).toFixed(1);
    document.getElementById('cpuProgress').style.width = cpuUsage + '%';
    document.getElementById('cpuPercent').textContent = cpuUsage + '%';
    document.getElementById('cpuFreq').textContent = cpuFreq + ' GHz';
    
    // GPU Metrics
    const gpuUsage = Math.floor(Math.random() * 30 + 65);
    const gpuFreq = Math.floor(Math.random() * 150 + 750);
    document.getElementById('gpuProgress').style.width = gpuUsage + '%';
    document.getElementById('gpuPercent').textContent = gpuUsage + '%';
    document.getElementById('gpuFreq').textContent = gpuFreq + ' MHz';
    
    // Memory Metrics
    const memUsage = Math.floor(Math.random() * 20 + 60);
    const memUsed = (10 * memUsage / 100).toFixed(1);
    document.getElementById('memProgress').style.width = memUsage + '%';
    document.getElementById('memUsed').textContent = memUsed + ' GB';
    
    // Temperature
    const temp = Math.floor(Math.random() * 20 + 35);
    document.getElementById('tempDisplay').textContent = temp + '°C';
    
    const tempStatus = document.getElementById('tempStatus');
    if (temp < 50) {
        tempStatus.textContent = 'Normal';
        tempStatus.style.background = 'rgba(0, 255, 136, 0.2)';
        tempStatus.style.color = 'var(--success)';
    } else if (temp < 70) {
        tempStatus.textContent = 'Warm';
        tempStatus.style.background = 'rgba(255, 170, 0, 0.2)';
        tempStatus.style.color = 'var(--warning)';
    } else {
        tempStatus.textContent = 'Hot';
        tempStatus.style.background = 'rgba(255, 51, 102, 0.2)';
        tempStatus.style.color = 'var(--danger)';
    }
}

// Load recent logs
function loadLogs() {
    // In production, this would read from /data/adb/modules/AXHyperBoost/logs/
    const logEntries = [
        { time: getCurrentTime(), message: 'Dashboard loaded', type: 'info' },
        { time: getCurrentTime(-5), message: 'Gaming profile active', type: 'success' },
        { time: getCurrentTime(-10), message: 'CPU boost enabled', type: 'info' },
        { time: getCurrentTime(-15), message: 'GPU optimization applied', type: 'success' },
        { time: getCurrentTime(-20), message: 'Touch response optimized', type: 'info' }
    ];
    
    const container = document.getElementById('logContainer');
    container.innerHTML = '';
    
    logEntries.forEach(log => {
        const entry = document.createElement('div');
        entry.className = `log-entry ${log.type}`;
        entry.innerHTML = `
            <span class="log-time">${log.time}</span>
            <span class="log-msg">${log.message}</span>
        `;
        container.appendChild(entry);
    });
}

// Helper function to get current time
function getCurrentTime(offset = 0) {
    const now = new Date();
    now.setSeconds(now.getSeconds() + offset);
    return now.toTimeString().split(' ')[0];
}

// Real-time log monitoring (if available)
function monitorLogs() {
    // This would use AXeron API to tail log files
    // Placeholder for future implementation
    console.log('Log monitoring active');
}
