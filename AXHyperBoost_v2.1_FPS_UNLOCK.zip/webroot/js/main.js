// AX HyperBoost Control Panel JavaScript

let currentProfile = 'gaming';

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    loadCurrentProfile();
    updateStats();
    setInterval(updateStats, 5000); // Update stats every 5 seconds
});

// Set performance profile
function setProfile(profile) {
    currentProfile = profile;
    
    // Update UI
    document.querySelectorAll('.profile-card').forEach(card => {
        card.classList.remove('active');
    });
    event.target.closest('.profile-card').classList.add('active');
    
    document.getElementById('currentProfile').textContent = 
        profile.charAt(0).toUpperCase() + profile.slice(1);
    
    // Call native engine
    executeCommand('axengine', `--${profile}`);
    
    showNotification(`${profile.toUpperCase()} mode activated`, 'success');
}

// Run engine with current settings
function runEngine() {
    executeCommand('axengine', `--${currentProfile}`);
    showNotification('Performance settings applied', 'success');
}

// Optimize GPU
function optimizeGPU() {
    executeCommand('gpuopt', '');
    showNotification('GPU optimization complete', 'success');
}

// Boost touch response
function boostTouch() {
    executeCommand('touchboost', '');
    showNotification('Touch response optimized', 'success');
}

// View logs
function viewLogs() {
    window.location.href = 'dashboard.html';
}

// Execute native command (placeholder - actual implementation depends on AXeron API)
function executeCommand(binary, args) {
    // This would be replaced with actual AXeron API call
    console.log(`Executing: /data/adb/modules/AXHyperBoost/core/bin/${binary} ${args}`);
    
    // Example API call (adjust based on AXeron's actual implementation)
    if (typeof AndroidInterface !== 'undefined') {
        AndroidInterface.executeCommand(`/data/adb/modules/AXHyperBoost/core/bin/${binary} ${args}`);
    } else {
        // Fallback for testing in browser
        fetch(`/api/execute`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ binary, args })
        }).catch(err => console.log('API not available:', err));
    }
}

// Update system stats (placeholder - would get real data from system)
function updateStats() {
    // These would be replaced with actual system readings
    const stats = {
        cpu: Math.floor(Math.random() * 30 + 60) + '%',
        gpu: Math.floor(Math.random() * 30 + 65) + '%',
        temp: Math.floor(Math.random() * 15 + 35) + '°C',
        fps: Math.floor(Math.random() * 10 + 55) + ' FPS'
    };
    
    document.getElementById('cpuUsage').textContent = stats.cpu;
    document.getElementById('gpuUsage').textContent = stats.gpu;
    document.getElementById('temperature').textContent = stats.temp;
    document.getElementById('fps').textContent = stats.fps;
}

// Load current profile from config
function loadCurrentProfile() {
    // Would read from /data/adb/modules/AXHyperBoost/config/axeron.conf
    // For now, using default
    const profile = currentProfile;
    document.getElementById('currentProfile').textContent = 
        profile.charAt(0).toUpperCase() + profile.slice(1);
}

// Show notification
function showNotification(message, type = 'info') {
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    notification.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: ${type === 'success' ? 'var(--success)' : 'var(--primary)'};
        color: white;
        padding: 15px 25px;
        border-radius: 10px;
        box-shadow: 0 5px 20px rgba(0, 0, 0, 0.3);
        z-index: 1000;
        animation: slideIn 0.3s ease;
    `;
    
    document.body.appendChild(notification);
    
    // Remove after 3 seconds
    setTimeout(() => {
        notification.style.animation = 'slideOut 0.3s ease';
        setTimeout(() => notification.remove(), 300);
    }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
    @keyframes slideIn {
        from {
            transform: translateX(400px);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOut {
        from {
            transform: translateX(0);
            opacity: 1;
        }
        to {
            transform: translateX(400px);
            opacity: 0;
        }
    }
`;
document.head.appendChild(style);
