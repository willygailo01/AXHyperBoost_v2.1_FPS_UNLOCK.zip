#!/system/bin/sh
# AX HyperBoost - Action Button
# This script runs when user clicks Action button in AxManager

MODDIR=${0%/*}

# Toggle between profiles
CURRENT=$(grep "current_profile" "$MODDIR/config/axeron.conf" | cut -d'=' -f2)

case "$CURRENT" in
    battery)
        NEXT="balanced"
        ;;
    balanced)
        NEXT="gaming"
        ;;
    gaming)
        NEXT="extreme"
        ;;
    *)
        NEXT="battery"
        ;;
esac

# Update config
sed -i "s/current_profile=.*/current_profile=$NEXT/" "$MODDIR/config/axeron.conf"

# Apply new profile
axengine --${NEXT}

echo "Profile switched to: $NEXT"
