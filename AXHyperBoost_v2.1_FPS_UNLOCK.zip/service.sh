#!/system/bin/sh
# AX HyperBoost - Service
# This script runs on BOOT_COMPLETED late_start service

MODDIR=${0%/*}

# Wait for system to stabilize
sleep 5

echo "[$(date)] AX HyperBoost service started" >> "$MODDIR/logs/service.log"

# Execute main engine with default profile
axengine --boot &

echo "[$(date)] Engine launched" >> "$MODDIR/logs/service.log"
