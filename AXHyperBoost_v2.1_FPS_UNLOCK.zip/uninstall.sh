#!/system/bin/sh
# AX HyperBoost ULTIMATE - Uninstall Script
# ==========================================
# This script completely removes AX HyperBoost and restores system to default state
# Compatible with: AxManager Plugin System

MODDIR=${0%/*}
MODID="ax.hyperboost"

# Logging function
log_info() {
    echo "[AXH-UNINSTALL] $1"
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$MODDIR/logs/uninstall.log"
}

# Create log directory if it doesn't exist
mkdir -p "$MODDIR/logs"

log_info "========================================="
log_info "AX HyperBoost ULTIMATE - Uninstall Started"
log_info "========================================="

# 1. Stop all running processes/services
log_info "Stopping AX HyperBoost services..."
killall axengine 2>/dev/null
killall gpuopt 2>/dev/null
killall touchboost 2>/dev/null
log_info "Services stopped"

# 2. Restore CPU settings to default
log_info "Restoring CPU settings to default..."
for cpu in /sys/devices/system/cpu/cpu*/cpufreq/; do
    if [ -d "$cpu" ]; then
        # Restore default governor (usually 'schedutil' or 'interactive')
        echo "schedutil" > "${cpu}scaling_governor" 2>/dev/null || echo "interactive" > "${cpu}scaling_governor" 2>/dev/null
        
        # Reset CPU frequencies to auto
        if [ -f "${cpu}scaling_max_freq" ]; then
            cat "${cpu}cpuinfo_max_freq" > "${cpu}scaling_max_freq" 2>/dev/null
        fi
        if [ -f "${cpu}scaling_min_freq" ]; then
            cat "${cpu}cpuinfo_min_freq" > "${cpu}scaling_min_freq" 2>/dev/null
        fi
    fi
done
log_info "CPU settings restored"

# 3. Restore GPU settings to default
log_info "Restoring GPU settings..."
# Common GPU paths for different SoCs
GPU_PATHS=(
    "/sys/class/kgsl/kgsl-3d0"
    "/sys/kernel/gpu"
    "/proc/gpufreq"
    "/proc/mali"
)

for gpu_path in "${GPU_PATHS[@]}"; do
    if [ -d "$gpu_path" ]; then
        # Reset GPU governor if exists
        [ -f "${gpu_path}/devfreq/governor" ] && echo "simple_ondemand" > "${gpu_path}/devfreq/governor" 2>/dev/null
        
        # Reset GPU frequencies
        if [ -f "${gpu_path}/max_gpuclk" ]; then
            cat "${gpu_path}/max_gpuclk" > "${gpu_path}/devfreq/max_freq" 2>/dev/null
        fi
        if [ -f "${gpu_path}/min_gpuclk" ]; then
            cat "${gpu_path}/min_gpuclk" > "${gpu_path}/devfreq/min_freq" 2>/dev/null
        fi
    fi
done
log_info "GPU settings restored"

# 4. Restore I/O scheduler to default
log_info "Restoring I/O scheduler..."
for block in /sys/block/*/queue/scheduler; do
    if [ -f "$block" ]; then
        # Restore to cfq or deadline (common defaults)
        echo "cfq" > "$block" 2>/dev/null || echo "deadline" > "$block" 2>/dev/null
    fi
done
log_info "I/O scheduler restored"

# 5. Restore thermal settings
log_info "Re-enabling thermal management..."
THERMAL_PATHS=(
    "/sys/class/thermal"
    "/sys/devices/virtual/thermal"
)

for thermal_path in "${THERMAL_PATHS[@]}"; do
    if [ -d "$thermal_path" ]; then
        for zone in ${thermal_path}/thermal_zone*/mode; do
            [ -f "$zone" ] && echo "enabled" > "$zone" 2>/dev/null
        done
    fi
done
log_info "Thermal management re-enabled"

# 6. Restore TCP/Network settings
log_info "Restoring network settings..."
# Restore default TCP congestion control
echo "cubic" > /proc/sys/net/ipv4/tcp_congestion_control 2>/dev/null

# Reset network buffer sizes to moderate defaults
echo "4096 87380 6291456" > /proc/sys/net/ipv4/tcp_rmem 2>/dev/null
echo "4096 16384 4194304" > /proc/sys/net/ipv4/tcp_wmem 2>/dev/null
log_info "Network settings restored"

# 7. Restore VM/Memory settings
log_info "Restoring memory management..."
echo "100" > /proc/sys/vm/swappiness 2>/dev/null
echo "0" > /proc/sys/vm/oom_kill_allocating_task 2>/dev/null
log_info "Memory settings restored"

# 8. Remove profile configuration files
log_info "Removing configuration files..."
rm -f "$MODDIR/config/axeron.conf" 2>/dev/null
rm -f "$MODDIR/config/.current_profile" 2>/dev/null
log_info "Configuration files removed"

# 9. Clean up logs (but keep uninstall log)
log_info "Cleaning up old logs..."
find "$MODDIR/logs" -type f ! -name "uninstall.log" -delete 2>/dev/null
log_info "Logs cleaned"

# 10. Remove custom kernel parameters
log_info "Removing custom kernel parameters..."
if [ -f /proc/sys/kernel/sched_latency_ns ]; then
    echo "6000000" > /proc/sys/kernel/sched_latency_ns 2>/dev/null
fi
if [ -f /proc/sys/kernel/sched_min_granularity_ns ]; then
    echo "750000" > /proc/sys/kernel/sched_min_granularity_ns 2>/dev/null
fi
log_info "Kernel parameters restored"

# 11. Clear any cached optimizations
log_info "Clearing cached data..."
sync
echo 3 > /proc/sys/vm/drop_caches 2>/dev/null
log_info "Cache cleared"

# 12. Remove any leftover PIDs or lock files
log_info "Removing temporary files..."
rm -f /data/local/tmp/axengine.pid 2>/dev/null
rm -f /data/local/tmp/axhyperboost.lock 2>/dev/null
log_info "Temporary files removed"

# 13. Final cleanup - remove system binaries from PATH
log_info "Cleaning up system binaries..."
# Note: The actual binary removal is handled by AxManager
# We just log this for user information
log_info "System binaries will be removed by AxManager"

# 14. Display summary
log_info "========================================="
log_info "Uninstall Summary:"
log_info "- All services stopped"
log_info "- CPU/GPU settings restored to default"
log_info "- Thermal management re-enabled"
log_info "- Network settings restored"
log_info "- Configuration files removed"
log_info "- System optimizations reverted"
log_info "========================================="
log_info "AX HyperBoost ULTIMATE uninstalled successfully!"
log_info "Please REBOOT your device to complete removal."
log_info "========================================="

# Create a flag file to indicate uninstall completion
touch "$MODDIR/logs/.uninstall_complete"

# Final message
echo ""
echo "╔════════════════════════════════════════╗"
echo "║  AX HyperBoost ULTIMATE Uninstalled    ║"
echo "║                                        ║"
echo "║  All settings restored to default      ║"
echo "║  Please REBOOT your device             ║"
echo "║                                        ║"
echo "║  Thank you for using AX HyperBoost!    ║"
echo "╔════════════════════════════════════════╗"
echo ""

exit 0
