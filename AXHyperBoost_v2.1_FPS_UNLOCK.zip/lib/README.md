# AX HyperBoost Native Libraries

This directory is designated for **shared native libraries (.so files)** that provide low-level performance optimizations for the AX HyperBoost engine.

---

## 📚 Expected Libraries

### Core Performance Libraries:

- **libaxperf.so** - Main performance engine library
  - CPU frequency management
  - Governor control
  - Thermal monitoring
  - Performance metrics collection

- **libgpubalancer.so** - GPU load balancing library
  - GPU frequency scaling
  - Power level management
  - Thermal-aware GPU throttling
  - Multi-GPU coordination

- **libtouchopt.so** - Touch optimization library
  - Input latency reduction
  - Touch sampling rate optimization
  - Touch pressure calibration
  - Gesture prediction

---

## 📁 Current Implementation

### Script-Based Approach:

**For this release**, the module uses **pure shell scripts** located in `system/bin/`:
- `axengine` - Performance engine (replaces libaxperf.so)
- `gpuopt` - GPU optimizer (replaces libgpubalancer.so)
- `touchboost` - Touch optimizer (replaces libtouchopt.so)

**Why shell scripts?**
- ✅ Universal compatibility (all Android devices)
- ✅ No compilation required
- ✅ Easy to modify and debug
- ✅ Works on non-rooted devices via AxManager
- ✅ No ABI (arm/arm64/x86/x64) concerns

---

## 🔧 Building Native Libraries (Future Enhancement)

If you want to create **actual native libraries** for better performance:

### Prerequisites:

1. **Android NDK** (Native Development Kit)
   ```bash
   # Download from:
   https://developer.android.com/ndk/downloads
   ```

2. **CMake** or **ndk-build**
   ```bash
   # Install CMake
   sudo apt-get install cmake
   ```

3. **C/C++ Compiler Toolchain**

---

### Method 1: Using CMake

#### Project Structure:
```
lib/
├── CMakeLists.txt
├── src/
│   ├── axperf.cpp
│   ├── gpubalancer.cpp
│   └── touchopt.cpp
├── include/
│   ├── axperf.h
│   ├── gpubalancer.h
│   └── touchopt.h
└── jni/
    └── Android.mk (optional)
```

#### CMakeLists.txt Example:
```cmake
cmake_minimum_required(VERSION 3.4.1)
project(AXHyperBoost)

# Set C++ standard
set(CMAKE_CXX_STANDARD 17)

# Find Android log library
find_library(log-lib log)

# Main performance library
add_library(axperf SHARED
    src/axperf.cpp
)
target_link_libraries(axperf ${log-lib})

# GPU balancer library
add_library(gpubalancer SHARED
    src/gpubalancer.cpp
)
target_link_libraries(gpubalancer ${log-lib})

# Touch optimizer library
add_library(touchopt SHARED
    src/touchopt.cpp
)
target_link_libraries(touchopt ${log-lib})
```

#### Build Commands:
```bash
# For ARM64 (most common)
mkdir -p build/arm64-v8a
cd build/arm64-v8a
cmake -DCMAKE_TOOLCHAIN_FILE=$NDK_PATH/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=arm64-v8a \
      -DANDROID_PLATFORM=android-21 \
      ../..
make

# For ARMv7
mkdir -p build/armeabi-v7a
cd build/armeabi-v7a
cmake -DCMAKE_TOOLCHAIN_FILE=$NDK_PATH/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=armeabi-v7a \
      -DANDROID_PLATFORM=android-21 \
      ../..
make

# For x86_64
mkdir -p build/x86_64
cd build/x86_64
cmake -DCMAKE_TOOLCHAIN_FILE=$NDK_PATH/build/cmake/android.toolchain.cmake \
      -DANDROID_ABI=x86_64 \
      -DANDROID_PLATFORM=android-21 \
      ../..
make
```

---

### Method 2: Using ndk-build

#### Android.mk Example:
```makefile
LOCAL_PATH := $(call my-dir)

# Main performance library
include $(CLEAR_VARS)
LOCAL_MODULE := axperf
LOCAL_SRC_FILES := src/axperf.cpp
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)

# GPU balancer library
include $(CLEAR_VARS)
LOCAL_MODULE := gpubalancer
LOCAL_SRC_FILES := src/gpubalancer.cpp
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)

# Touch optimizer library
include $(CLEAR_VARS)
LOCAL_MODULE := touchopt
LOCAL_SRC_FILES := src/touchopt.cpp
LOCAL_LDLIBS := -llog
include $(BUILD_SHARED_LIBRARY)
```

#### Application.mk Example:
```makefile
APP_ABI := arm64-v8a armeabi-v7a x86_64
APP_PLATFORM := android-21
APP_STL := c++_shared
```

#### Build Command:
```bash
ndk-build NDK_PROJECT_PATH=. NDK_APPLICATION_MK=./Application.mk
```

---

## 📦 Library Placement (After Building)

After compilation, organize libraries by ABI:

```
lib/
├── arm64-v8a/
│   ├── libaxperf.so
│   ├── libgpubalancer.so
│   └── libtouchopt.so
├── armeabi-v7a/
│   ├── libaxperf.so
│   ├── libgpubalancer.so
│   └── libtouchopt.so
├── x86_64/
│   ├── libaxperf.so
│   ├── libgpubalancer.so
│   └── libtouchopt.so
└── x86/
    ├── libaxperf.so
    ├── libgpubalancer.so
    └── libtouchopt.so
```

---

## 🔗 Loading Libraries in Scripts

### Update system/bin/axengine:

```bash
#!/system/bin/sh

MODDIR="${0%/*}/../.."
ARCH=$(getprop ro.product.cpu.abi)

# Load native library if available
if [ -f "$MODDIR/lib/$ARCH/libaxperf.so" ]; then
    export LD_LIBRARY_PATH="$MODDIR/lib/$ARCH:$LD_LIBRARY_PATH"
    
    # Call native performance engine
    axperf_native --optimize
else
    # Fall back to shell script implementation
    # ... existing shell script code ...
fi
```

---

## 🎯 Example: Simple libaxperf.cpp

```cpp
#include <android/log.h>
#include <fstream>
#include <string>

#define LOG_TAG "AXPerf"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)

extern "C" {

// Set CPU governor
void setCpuGovernor(const char* governor) {
    std::string path = "/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor";
    std::ofstream file(path);
    
    if (file.is_open()) {
        file << governor;
        file.close();
        LOGI("CPU governor set to: %s", governor);
    }
}

// Enable CPU boost
void enableCpuBoost(bool enable) {
    std::string path = "/sys/devices/system/cpu/cpufreq/boost";
    std::ofstream file(path);
    
    if (file.is_open()) {
        file << (enable ? "1" : "0");
        file.close();
        LOGI("CPU boost: %s", enable ? "enabled" : "disabled");
    }
}

// Main optimization entry point
int optimizePerformance(const char* mode) {
    LOGI("Starting performance optimization: %s", mode);
    
    if (strcmp(mode, "gaming") == 0) {
        setCpuGovernor("performance");
        enableCpuBoost(true);
    } else if (strcmp(mode, "battery") == 0) {
        setCpuGovernor("powersave");
        enableCpuBoost(false);
    } else {
        setCpuGovernor("schedutil");
        enableCpuBoost(true);
    }
    
    return 0;
}

} // extern "C"
```

---

## 🔄 Integration with AxManager

### For AxManager Plugin:

1. Libraries should be placed in `lib/` directory
2. AxManager will handle ABI detection
3. Scripts in `system/bin/` should check for native libraries first
4. Fall back to shell implementation if libraries not found

### Library Loading Priority:

```
1. Check for native library: lib/$ARCH/libaxperf.so
2. If found: Use native implementation
3. If not found: Use shell script implementation
4. Log the method being used
```

---

## 📊 Performance Comparison

### Shell Script Implementation:
- ✅ **Compatibility:** 100% (all devices)
- ✅ **Portability:** Universal
- ⚠️ **Speed:** Moderate (sufficient for most cases)
- ✅ **Debug:** Easy
- ✅ **Maintenance:** Simple

### Native Library Implementation:
- ⚠️ **Compatibility:** Requires correct ABI
- ⚠️ **Portability:** Must compile for each ABI
- ✅ **Speed:** Very fast
- ⚠️ **Debug:** Requires NDK tools
- ⚠️ **Maintenance:** More complex

---

## 🎯 Recommendation

### Current Release (v2.0):
**Use shell scripts** for maximum compatibility and ease of use.

### Future Enhancement (v3.0+):
Consider native libraries for:
- Advanced thermal prediction algorithms
- Real-time FPS monitoring
- Complex mathematical operations
- High-frequency sensor polling
- Machine learning inference

---

## 📝 Development Roadmap

### Phase 1 (Current): Shell Scripts ✅
- Pure shell implementation
- Universal compatibility
- Easy debugging

### Phase 2 (Future): Hybrid Approach
- Native libraries for performance-critical code
- Shell scripts for compatibility
- Automatic fallback

### Phase 3 (Advanced): Full Native
- Complete native implementation
- JNI bridge for Android integration
- Advanced optimizations

---

## 🛠️ Building Tips

### Optimization Flags:
```cmake
set(CMAKE_CXX_FLAGS "${CMAKE_CXX_FLAGS} -O3 -ffast-math")
set(CMAKE_C_FLAGS "${CMAKE_C_FLAGS} -O3 -ffast-math")
```

### Strip Symbols (Reduce Size):
```bash
$NDK_PATH/toolchains/llvm/prebuilt/linux-x86_64/bin/llvm-strip libaxperf.so
```

### Test on Device:
```bash
adb push lib/arm64-v8a/libaxperf.so /data/local/tmp/
adb shell chmod 755 /data/local/tmp/libaxperf.so
adb shell /data/local/tmp/libaxperf.so
```

---

## 📚 Resources

### Official Documentation:
- [Android NDK Guide](https://developer.android.com/ndk/guides)
- [CMake for Android](https://developer.android.com/ndk/guides/cmake)
- [JNI Tips](https://developer.android.com/training/articles/perf-jni)

### Example Projects:
- [Android NDK Samples](https://github.com/android/ndk-samples)
- [Native Audio](https://github.com/android/ndk-samples/tree/main/native-audio)

---

## 🎊 Conclusion

This directory is **ready for native libraries** but currently uses **shell scripts** for maximum compatibility. If you want to contribute native implementations, follow the guidelines above and submit a pull request!

**For the current release, no action is needed** - everything works perfectly with shell scripts! 🚀

---

**Module Version:** 2.0  
**Implementation:** Shell Script (100% compatible)  
**Future:** Native Library Support Ready  
**Status:** Production Ready ✅
